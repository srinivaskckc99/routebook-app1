import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  MapPin, 
  Search, 
  Star, 
  Phone, 
  Mail, 
  User, 
  Image as ImageIcon, 
  Calendar, 
  Edit2, 
  Trash2, 
  Check, 
  Clock, 
  ChevronRight, 
  Folder, 
  Download, 
  Upload, 
  CheckCircle2, 
  Compass, 
  Navigation,
  ArrowLeft,
  Sun,
  Moon,
  MessageSquare,
  AlertCircle,
  LogOut,
  RefreshCw
} from 'lucide-react';
import { LocationNote, CategoryType } from '../types';
import MapPicker from './MapPicker';

interface AndroidEmulatorProps {
  locations: LocationNote[];
  setLocations: React.Dispatch<React.SetStateAction<LocationNote[]>>;
  activeScreen: 'home' | 'picker' | 'details' | 'view_details';
  setActiveScreen: (screen: 'home' | 'picker' | 'details' | 'view_details') => void;
  selectedLocation: LocationNote | null;
  setSelectedLocation: (loc: LocationNote | null) => void;
  appTheme: 'light' | 'dark';
  setAppTheme: (theme: 'light' | 'dark') => void;
  
  // Auth & Cloud Sync
  currentUser: any;
  onSignIn: () => void;
  onSignOut: () => void;
  syncStatus: 'idle' | 'syncing' | 'synced' | 'error' | 'pending';
  onManualSync: () => void;

  // Import/Export
  onExportExcel: () => void;
  onImportFile: (file: File) => void;
  importSummary: any;
  importError: string | null;
  setImportSummary: (val: any) => void;
  setImportError: (val: string | null) => void;
}

const CATEGORIES: CategoryType[] = [
  'Pharmacy', 'Grocery', 'Customer', 'Office', 'Restaurant', 'Warehouse', 'Dealer', 'Hospital', 'Other'
];

export default function AndroidEmulator({
  locations,
  setLocations,
  activeScreen,
  setActiveScreen,
  selectedLocation,
  setSelectedLocation,
  appTheme,
  setAppTheme,
  currentUser,
  onSignIn,
  onSignOut,
  syncStatus,
  onManualSync,
  onExportExcel,
  onImportFile,
  importSummary,
  importError,
  setImportSummary,
  setImportError
}: AndroidEmulatorProps) {
  // Simulator Navigation & Local forms state
  const [isSplashScreen, setIsSplashScreen] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState('All');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Form fields for adding/editing a location note
  const [editingLocationId, setEditingLocationId] = useState<string | null>(null);
  const [selectedLat, setSelectedLat] = useState<number>(30.2672);
  const [selectedLng, setSelectedLng] = useState<number>(-97.7431);
  const [selectedAddress, setSelectedAddress] = useState<string>('701 Congress Ave, Austin, TX 78701');
  const [newPlaceName, setNewPlaceName] = useState('');
  const [newPlaceNotes, setNewPlaceNotes] = useState('');
  const [newPlaceCategory, setNewPlaceCategory] = useState<CategoryType>('Customer');
  const [nameError, setNameError] = useState<string | null>(null);

  const [newPlaceIsFavorite, setNewPlaceIsFavorite] = useState(false);
  const [newPlaceColorLabel, setNewPlaceColorLabel] = useState<'red' | 'green' | 'blue' | 'yellow'>('green');
  const [newPlaceOwnerName, setNewPlaceOwnerName] = useState('');
  const [newPlacePhone, setNewPlacePhone] = useState('');
  const [newPlaceWhatsapp, setNewPlaceWhatsapp] = useState('');
  const [newPlaceEmail, setNewPlaceEmail] = useState('');
  const [newPlaceBullets, setNewPlaceBullets] = useState<string[]>([]);
  const [newPlaceChecklist, setNewPlaceChecklist] = useState<{ id: string; text: string; done: boolean }[]>([]);
  const [newPlaceReminderInterval, setNewPlaceReminderInterval] = useState<number | null>(null);

  // Helpers for Rich Bullet List & Checklist
  const [bulletInput, setBulletInput] = useState('');
  const [checklistInput, setChecklistInput] = useState('');
  const [isAdvancedExpanded, setIsAdvancedExpanded] = useState(false);

  // Visit history logger state
  const [isCheckInDialogOpen, setIsCheckInDialogOpen] = useState(false);
  const [visitNoteText, setVisitNoteText] = useState('');
  const [isGettingLocation, setIsGettingLocation] = useState(false);

  // Auto-dismiss Splash screen simulation
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsSplashScreen(false);
    }, 2200);
    return () => clearTimeout(timer);
  }, []);

  const resetForm = () => {
    setEditingLocationId(null);
    setNewPlaceName('');
    setNewPlaceNotes('');
    setNewPlaceCategory('Customer');
    setNewPlaceIsFavorite(false);
    setNewPlaceColorLabel('green');
    setNewPlaceOwnerName('');
    setNewPlacePhone('');
    setNewPlaceWhatsapp('');
    setNewPlaceEmail('');
    setNewPlaceBullets([]);
    setNewPlaceChecklist([]);
    setNewPlaceReminderInterval(null);
    setBulletInput('');
    setChecklistInput('');
    setNameError(null);
    setIsAdvancedExpanded(false);
  };

  // Launch Form prefilled if editing
  const startEditLocation = (loc: LocationNote, e: React.MouseEvent) => {
    e.stopPropagation();
    resetForm();
    setEditingLocationId(loc.id);
    setSelectedLat(loc.latitude);
    setSelectedLng(loc.longitude);
    setSelectedAddress(loc.address);
    setNewPlaceName(loc.shopName);
    setNewPlaceNotes(loc.notes);
    setNewPlaceCategory(loc.category);
    setNewPlaceIsFavorite(loc.isFavorite || false);
    setNewPlaceColorLabel(loc.colorLabel || 'green');
    setNewPlaceOwnerName(loc.contactInfo?.ownerName || '');
    setNewPlacePhone(loc.contactInfo?.phone || '');
    setNewPlaceWhatsapp(loc.contactInfo?.whatsapp || '');
    setNewPlaceEmail(loc.contactInfo?.email || '');
    setNewPlaceBullets(loc.richNotes?.bullets || []);
    setNewPlaceChecklist(loc.richNotes?.checklists || []);
    setNewPlaceReminderInterval(loc.reminderInterval || null);

    setActiveScreen('details');
  };

  // Triggers "+" button action -> Go to Map Picker
  const handleAddNewLocationInit = () => {
    resetForm();
    setSelectedLat(30.2672);
    setSelectedLng(-97.7431);
    setSelectedAddress('701 Congress Ave, Austin, TX 78701');
    setActiveScreen('picker');
  };

  // Confirm map coordinates -> Proceed to filling detail text fields
  const handleConfirmPinLocation = () => {
    setActiveScreen('details');
  };

  // Save/Submit Form Note
  const handleSaveLocation = () => {
    if (!newPlaceName.trim()) {
      setNameError('Location name is required');
      return;
    }
    setNameError(null);

    const completeItem: LocationNote = {
      id: editingLocationId || `loc-${Math.random().toString(36).substring(2, 11)}-${Date.now()}`,
      shopName: newPlaceName.trim(),
      latitude: selectedLat,
      longitude: selectedLng,
      address: selectedAddress,
      notes: newPlaceNotes.trim(),
      category: newPlaceCategory,
      createdAt: editingLocationId ? (locations.find(l => l.id === editingLocationId)?.createdAt || Date.now()) : Date.now(),
      updatedAt: Date.now(),
      isFavorite: newPlaceIsFavorite,
      colorLabel: newPlaceColorLabel,
      contactInfo: {
        ownerName: newPlaceOwnerName.trim(),
        phone: newPlacePhone.trim(),
        whatsapp: newPlaceWhatsapp.trim(),
        email: newPlaceEmail.trim() || undefined
      },
      richNotes: {
        bullets: newPlaceBullets,
        checklists: newPlaceChecklist
      },
      reminderInterval: newPlaceReminderInterval,
      visitHistory: editingLocationId ? (locations.find(l => l.id === editingLocationId)?.visitHistory || []) : []
    };

    setLocations(prev => {
      const filtered = prev.filter(l => l.id !== completeItem.id);
      const updated = [completeItem, ...filtered];
      localStorage.setItem('routebook_sim_db', JSON.stringify(updated));
      return updated;
    });

    resetForm();
    setActiveScreen('home');
  };

  const handleDeleteLocation = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLocations(prev => {
      const updated = prev.filter(l => l.id !== id);
      localStorage.setItem('routebook_sim_db', JSON.stringify(updated));
      return updated;
    });
    setDeleteConfirmId(null);
    if (selectedLocation?.id === id) {
      setSelectedLocation(null);
    }
    setActiveScreen('home');
  };

  // Favorite toggle from details view screen
  const toggleFavorite = (id: string) => {
    setLocations(prev => {
      const updated = prev.map(l => l.id === id ? { ...l, isFavorite: !l.isFavorite, updatedAt: Date.now() } : l);
      localStorage.setItem('routebook_sim_db', JSON.stringify(updated));
      // Update selectedLocation reference too
      const current = updated.find(l => l.id === id);
      if (current) setSelectedLocation(current);
      return updated;
    });
  };

  // Rich metadata helper: Bullets adder
  const addBulletPoint = () => {
    if (!bulletInput.trim()) return;
    setNewPlaceBullets(prev => [...prev, bulletInput.trim()]);
    setBulletInput('');
  };

  // Rich metadata helper: Checklist adder
  const addChecklistItem = () => {
    if (!checklistInput.trim()) return;
    setNewPlaceChecklist(prev => [
      ...prev,
      { id: `chk-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`, text: checklistInput.trim(), done: false }
    ]);
    setChecklistInput('');
  };

  // Toggle checklist item from details view (interactive!)
  const toggleViewChecklistItem = (itemIdx: number) => {
    if (!selectedLocation) return;
    const updatedChecklist = [...(selectedLocation.richNotes?.checklists || [])];
    updatedChecklist[itemIdx].done = !updatedChecklist[itemIdx].done;

    setLocations(prev => {
      const updated = prev.map(l => l.id === selectedLocation.id ? {
        ...l,
        richNotes: {
          ...l.richNotes,
          checklists: updatedChecklist
        },
        updatedAt: Date.now()
      } : l);
      localStorage.setItem('routebook_sim_db', JSON.stringify(updated));
      const current = updated.find(l => l.id === selectedLocation.id);
      if (current) setSelectedLocation(current);
      return updated;
    });
  };

  // Record Visit Check-In Flow
  const handleCheckInSubmit = () => {
    if (!selectedLocation) return;
    setIsGettingLocation(true);

    // Capture simulated coordinates
    setTimeout(() => {
      setIsGettingLocation(false);
      const newVisit = {
        id: `v-visit-${Date.now()}`,
        timestamp: Date.now(),
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        notes: visitNoteText.trim() || 'Quick visited check-in recorded offline.',
        latitude: selectedLocation.latitude + (Math.random() - 0.5) * 0.001,
        longitude: selectedLocation.longitude + (Math.random() - 0.5) * 0.001,
      };

      const updatedHistory = [newVisit, ...(selectedLocation.visitHistory || [])];

      setLocations(prev => {
        const updated = prev.map(l => l.id === selectedLocation.id ? {
          ...l,
          visitHistory: updatedHistory,
          updatedAt: Date.now()
        } : l);
        localStorage.setItem('routebook_sim_db', JSON.stringify(updated));
        const current = updated.find(l => l.id === selectedLocation.id);
        if (current) setSelectedLocation(current);
        return updated;
      });

      setVisitNoteText('');
      setIsCheckInDialogOpen(false);
    }, 600);
  };

  // Search and Category filtering
  const filteredLocations = locations.filter(loc => {
    const matchesSearch = 
      loc.shopName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      loc.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      loc.notes.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategoryFilter === 'All' || loc.category === selectedCategoryFilter;
    return matchesSearch && matchesCategory;
  });

  const isDark = appTheme === 'dark';

  return (
    <div className={`w-[360px] h-[720px] rounded-[52px] border-[10px] ${
      isDark ? 'border-[#1C1B1F] bg-[#141218] text-[#E6E1E5]' : 'border-slate-800 bg-white text-slate-800'
    } shadow-3xl overflow-hidden flex flex-col relative select-none ring-8 ring-[#6750A4]/5`}>
      
      {/* Top Mobile Notch and Status Bar indicators */}
      <div className={`h-8 flex items-center justify-between px-6 z-40 relative text-[10px] font-bold ${
        isDark ? 'bg-[#141218] text-slate-300' : 'bg-[#FAF8FC] text-slate-600'
      }`}>
        <span className="font-mono">09:41</span>
        {/* Visual notch */}
        <div className="w-20 h-4 bg-black rounded-b-2xl absolute left-1/2 -translate-x-1/2 top-0" />
        <div className="flex items-center gap-1.5 font-mono">
          <span>5G</span>
          <span>100%</span>
        </div>
      </div>

      {/* Main Screen Content Frame */}
      <div className="flex-1 overflow-hidden relative flex flex-col min-h-0">
        <AnimatePresence mode="wait">
          {isSplashScreen ? (
            <SplashSimulatorScreen key="splash" isDark={isDark} />
          ) : (
            <div className="flex-grow flex flex-col min-h-0">
              
              {/* SCREEN 1: HOME LIST SCREEN */}
              {activeScreen === 'home' && (
                <div className="flex-1 flex flex-col min-h-0">
                  {/* Google Sync and Auth Banner */}
                  <div className={`px-4.5 py-3 border-b flex items-center justify-between gap-3 shrink-0 ${
                    isDark ? 'bg-[#25232A] border-[#36343B]' : 'bg-[#F3EDF7] border-[#E8E0EB]'
                  }`}>
                    {currentUser ? (
                      <div className="flex items-center gap-2 max-w-[65%]">
                        <img 
                          src={currentUser.photoURL || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=60&auto=format&fit=crop&q=80"} 
                          alt="avatar" 
                          className="w-5.5 h-5.5 rounded-full border border-[#6750A4]/30 object-cover" 
                          referrerPolicy="no-referrer"
                        />
                        <div className="truncate">
                          <p className="text-[8px] font-black leading-none text-[#6750A4]">Signed In</p>
                          <p className="text-[7px] text-[#49454F] font-bold truncate leading-none mt-0.5">{currentUser.email}</p>
                        </div>
                      </div>
                    ) : (
                      <button 
                        onClick={onSignIn}
                        className="text-[8px] font-black uppercase tracking-wider text-white bg-[#6750A4] px-2.5 py-1.5 rounded-lg hover:bg-[#533F8A] cursor-pointer"
                      >
                        Sign in for Sync
                      </button>
                    )}

                    <div className="flex items-center gap-1">
                      {currentUser && (
                        <button
                          onClick={onManualSync}
                          title="Trigger Cloud Sync Backup"
                          className={`p-1.5 rounded-lg border transition-all ${
                            syncStatus === 'syncing' ? 'animate-spin border-amber-500 text-amber-500' : 'border-slate-300 text-[#49454F] hover:bg-[#FAF8FC]'
                          }`}
                        >
                          <RefreshCw className="w-2.5 h-2.5" />
                        </button>
                      )}
                      {currentUser && (
                        <button
                          onClick={onSignOut}
                          title="Logout"
                          className="p-1.5 rounded-lg border border-slate-300 text-red-500 hover:bg-red-50/20"
                        >
                          <LogOut className="w-2.5 h-2.5" />
                        </button>
                      )}
                      
                      {/* Theme Toggle inside Phone */}
                      <button
                        onClick={() => setAppTheme(isDark ? 'light' : 'dark')}
                        className="p-1.5 rounded-lg border border-slate-300 text-amber-500 hover:bg-amber-50/20"
                      >
                        {isDark ? <Sun className="w-2.5 h-2.5" /> : <Moon className="w-2.5 h-2.5" />}
                      </button>
                    </div>
                  </div>

                  {/* App Header, Excel Export/Import, & Filters */}
                  <div className={`px-4.5 pt-3.5 pb-2.5 border-b shrink-0 ${isDark ? 'bg-[#1D1B20] border-[#36343B]' : 'bg-[#FAF8FC] border-[#E8E0EB]'}`}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-black tracking-tight text-[#6750A4]">RouteBook Map</span>
                      
                      {/* Excel Actions */}
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={onExportExcel}
                          title="Export standard Excel sheet"
                          className="p-1 text-[#6750A4] hover:bg-[#FAF8FC] rounded-lg border border-[#CAC4D0] flex items-center gap-1 px-1.5 py-0.5 text-[7px] font-bold uppercase tracking-wider"
                        >
                          <Download className="w-2.5 h-2.5" />
                          <span>Export</span>
                        </button>
                        <label className="p-1 text-[#6750A4] hover:bg-[#FAF8FC] rounded-lg border border-[#CAC4D0] flex items-center gap-1 px-1.5 py-0.5 text-[7px] font-bold uppercase tracking-wider cursor-pointer">
                          <Upload className="w-2.5 h-2.5" />
                          <span>Import</span>
                          <input 
                            type="file" 
                            accept=".csv,.json" 
                            className="hidden" 
                            onChange={(e) => {
                              if (e.target.files?.[0]) onImportFile(e.target.files[0]);
                            }}
                          />
                        </label>
                      </div>
                    </div>

                    {/* Import Alerts */}
                    {importSummary && (
                      <div className="mb-2 p-1.5 rounded-lg bg-green-500/10 text-green-600 border border-green-500/20 text-[7px] flex items-center justify-between">
                        <span className="truncate">Added: {importSummary.added} | Merged: {importSummary.updated}</span>
                        <button onClick={() => setImportSummary(null)} className="font-bold hover:underline">Dismiss</button>
                      </div>
                    )}
                    {importError && (
                      <div className="mb-2 p-1.5 rounded-lg bg-red-500/10 text-red-500 border border-red-500/20 text-[7px] flex items-center justify-between">
                        <span className="truncate">{importError}</span>
                        <button onClick={() => setImportError(null)} className="font-bold hover:underline">Dismiss</button>
                      </div>
                    )}

                    {/* Search Field */}
                    <div className="relative flex items-center mb-2">
                      <Search className={`absolute left-3 w-3 h-3 ${isDark ? 'text-slate-500' : 'text-slate-400'}`} />
                      <input
                        type="text"
                        placeholder="Search locations or notes..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className={`w-full pl-8.5 pr-3 py-1.5 rounded-xl text-[10px] outline-none border ${
                          isDark 
                            ? 'bg-[#25232A] border-[#36343B] text-[#E6E1E5] placeholder-[#938F99] focus:border-[#D0BCFF]' 
                            : 'bg-white border-[#E8E0EB] text-slate-800 placeholder-slate-400 focus:border-[#6750A4]'
                        }`}
                      />
                    </div>

                    {/* Horizontal Category Filters */}
                    <div className="flex gap-1 overflow-x-auto scrollbar-none pb-0.5">
                      {['All', ...CATEGORIES].map((cat) => (
                        <button
                          key={cat}
                          onClick={() => setSelectedCategoryFilter(cat)}
                          className={`px-2.5 py-1 rounded-full text-[8px] font-black uppercase tracking-wider shrink-0 transition-all cursor-pointer border ${
                            selectedCategoryFilter === cat
                              ? 'bg-[#6750A4] border-[#6750A4] text-white'
                              : isDark 
                                ? 'bg-[#25232A] border-[#36343B] text-slate-300 hover:bg-slate-800'
                                : 'bg-white border-[#E8E0EB] text-[#49454F] hover:bg-slate-50'
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Scrollable Location List */}
                  <div className={`flex-1 overflow-y-auto p-4 space-y-3.5 min-h-0 ${isDark ? 'bg-[#141218]' : 'bg-[#FAF8FC]'}`}>
                    {filteredLocations.length === 0 ? (
                      <div className="text-center py-12 space-y-2">
                        <MapPin className="w-7 h-7 text-[#D0BCFF] mx-auto opacity-55 animate-bounce" />
                        <p className="text-[10px] font-bold text-slate-400">No Location Notes Saved</p>
                        <p className="text-[8px] text-slate-500 max-w-[80%] mx-auto leading-relaxed">
                          Click the purple floating "+" button below to select a map coordinate and save a new offline business note.
                        </p>
                      </div>
                    ) : (
                      filteredLocations.map((loc) => (
                        <div
                          key={loc.id}
                          onClick={() => {
                            setSelectedLocation(loc);
                            setActiveScreen('view_details');
                          }}
                          className={`p-3.5 rounded-2xl border shadow-xs transition-all hover:scale-98 relative group cursor-pointer ${
                            isDark 
                              ? 'bg-[#1D1B20] border-[#36343B] hover:bg-[#25232A]' 
                              : 'bg-white border-[#E8E0EB] hover:bg-slate-50/50'
                          }`}
                        >
                          {/* Top row */}
                          <div className="flex items-start justify-between gap-1.5 mb-1.5">
                            <div className="flex items-center gap-1.5">
                              {/* Color labels indicator */}
                              <span 
                                style={{
                                  backgroundColor: 
                                    loc.colorLabel === 'red' ? '#EA4335' : 
                                    loc.colorLabel === 'green' ? '#34A853' : 
                                    loc.colorLabel === 'blue' ? '#4285F4' : '#FBBC05'
                                }}
                                className="w-2.5 h-2.5 rounded-full shrink-0 shadow-xs"
                                title={`Priority: ${loc.colorLabel}`}
                              />
                              <h3 className={`text-[11px] font-black truncate max-w-[160px] ${isDark ? 'text-white' : 'text-[#1D1B20]'}`}>
                                {loc.shopName}
                              </h3>
                            </div>
                            <div className="flex items-center gap-1 shrink-0">
                              {loc.isFavorite && <Star className="w-3 h-3 text-amber-500 fill-amber-500" />}
                              <span className={`text-[7px] font-black uppercase px-2 py-0.5 rounded-full ${
                                isDark ? 'bg-white/5 text-[#D0BCFF]' : 'bg-[#E8DEF8] text-[#1D192B]'
                              }`}>
                                {loc.category}
                              </span>
                            </div>
                          </div>

                          {/* Address & Note snippet */}
                          <p className="text-[8px] text-slate-400 truncate flex items-center gap-1 mb-1 font-semibold leading-none">
                            <MapPin className="w-2.5 h-2.5 shrink-0 text-[#6750A4]" />
                            <span className="truncate">{loc.address}</span>
                          </p>
                          <p className="text-[9px] text-[#49454F] leading-normal line-clamp-2 italic">
                            "{loc.notes || 'No description notes recorded yet.'}"
                          </p>

                          {/* Action panel */}
                          <div className="mt-3 pt-2.5 border-t border-dashed border-[#E8E0EB] flex items-center justify-between text-[8px] font-black uppercase">
                            <span className="text-[7px] text-slate-400">
                              Visits: {loc.visitHistory?.length || 0}
                            </span>
                            <div className="flex items-center gap-3">
                              <button
                                onClick={(e) => startEditLocation(loc, e)}
                                className="text-[#6750A4] hover:underline flex items-center gap-0.5 cursor-pointer"
                              >
                                <Edit2 className="w-2.5 h-2.5" />
                                <span>Edit</span>
                              </button>
                              
                              {deleteConfirmId === loc.id ? (
                                <button
                                  onClick={(e) => handleDeleteLocation(loc.id, e)}
                                  className="text-red-600 hover:underline flex items-center gap-0.5 cursor-pointer"
                                >
                                  <Check className="w-2.5 h-2.5 text-red-600" />
                                  <span>Sure?</span>
                                </button>
                              ) : (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setDeleteConfirmId(loc.id);
                                    setTimeout(() => setDeleteConfirmId(null), 3000);
                                  }}
                                  className="text-red-500/70 hover:text-red-500 flex items-center gap-0.5 cursor-pointer"
                                >
                                  <Trash2 className="w-2.5 h-2.5" />
                                  <span>Delete</span>
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Floating Action Add Button */}
                  <button
                    onClick={handleAddNewLocationInit}
                    className="absolute bottom-5 right-5 w-12 h-12 bg-[#6750A4] hover:bg-[#533F8A] text-white rounded-2xl shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center justify-center cursor-pointer border border-[#D0BCFF]/10"
                  >
                    <Plus className="w-6 h-6 stroke-[2.5]" />
                  </button>
                </div>
              )}

              {/* SCREEN 2: MAP PIN PICKER SCREEN */}
              {activeScreen === 'picker' && (
                <div className="flex-1 flex flex-col min-h-0 relative">
                  {/* Map Header */}
                  <div className={`px-4.5 py-3 border-b flex items-center justify-between shrink-0 ${
                    isDark ? 'bg-[#1D1B20] border-[#36343B]' : 'bg-white border-[#E8E0EB]'
                  }`}>
                    <button 
                      onClick={() => setActiveScreen('home')}
                      className={`p-1.5 rounded-lg border hover:bg-slate-50 flex items-center gap-1 ${
                        isDark ? 'border-[#36343B] text-slate-200' : 'border-slate-200 text-slate-700'
                      }`}
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-[10px] font-black uppercase tracking-wider text-[#6750A4]">Pick Location Pin</span>
                    <div className="w-7 h-7" />
                  </div>

                  {/* Real/Sim Map container */}
                  <div className="flex-1 min-h-0">
                    <MapPicker
                      selectedLat={selectedLat}
                      setSelectedLat={setSelectedLat}
                      selectedLng={selectedLng}
                      setSelectedLng={setSelectedLng}
                      selectedAddress={selectedAddress}
                      setSelectedAddress={setSelectedAddress}
                      appTheme={appTheme}
                      setNewPlaceName={setNewPlaceName}
                    />
                  </div>

                  {/* Bottom Confirm CTA */}
                  <div className={`p-4.5 border-t flex flex-col gap-2 shrink-0 ${
                    isDark ? 'bg-[#1D1B20] border-[#36343B]' : 'bg-[#FAF8FC] border-[#E8E0EB]'
                  }`}>
                    <p className="text-[8px] text-center text-[#49454F] font-semibold italic">
                      "Confirming will store coordinates and open business details form."
                    </p>
                    <button
                      onClick={handleConfirmPinLocation}
                      className="w-full py-3 bg-[#6750A4] text-white font-black text-[10px] uppercase tracking-wider rounded-xl transition-all active:scale-98 shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Confirm Pin Location</span>
                    </button>
                  </div>
                </div>
              )}

              {/* SCREEN 3: DETAILS FORM SCREEN */}
              {activeScreen === 'details' && (
                <div className="flex-1 flex flex-col min-h-0">
                  {/* Form Header */}
                  <div className={`px-4.5 py-3 border-b flex items-center justify-between shrink-0 ${
                    isDark ? 'bg-[#1D1B20] border-[#36343B]' : 'bg-white border-[#E8E0EB]'
                  }`}>
                    <button 
                      onClick={() => setActiveScreen('picker')}
                      className={`p-1.5 rounded-lg border hover:bg-slate-50 flex items-center gap-1 ${
                        isDark ? 'border-[#36343B] text-slate-200' : 'border-slate-200 text-slate-700'
                      }`}
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-[10px] font-black uppercase tracking-wider text-[#6750A4]">
                      {editingLocationId ? 'Edit Details' : 'New Location Note'}
                    </span>
                    <div className="w-7 h-7" />
                  </div>

                  {/* Scrollable form body */}
                  <div className={`flex-1 overflow-y-auto p-4.5 space-y-4.5 min-h-0 ${isDark ? 'bg-[#141218]' : 'bg-[#FAF8FC]'}`}>
                    
                    {/* Location coordinates summary card */}
                    <div className={`p-3 rounded-xl border flex items-center gap-2.5 ${
                      isDark ? 'bg-[#25232A] border-[#36343B]' : 'bg-white border-[#E8E0EB]'
                    }`}>
                      <MapPin className="w-6 h-6 text-[#6750A4] shrink-0" />
                      <div className="min-w-0 flex-1">
                        <p className="text-[7.5px] text-[#49454F] font-black uppercase tracking-wider">Coordinates selected</p>
                        <p className="text-[8px] font-mono text-slate-500 font-bold leading-tight">
                          Lat: {selectedLat.toFixed(5)} | Lng: {selectedLng.toFixed(5)}
                        </p>
                        <p className="text-[9px] font-semibold text-slate-700 truncate leading-none mt-1">{selectedAddress}</p>
                      </div>
                    </div>

                    {/* Shop Name Field */}
                    <div className="space-y-1">
                      <label className="text-[9px] font-black uppercase tracking-wider text-[#49454F]">Location / Shop Name *</label>
                      <input
                        type="text"
                        placeholder="e.g. Apex Pharmacy, Westside Warehouse..."
                        value={newPlaceName}
                        onChange={(e) => setNewPlaceName(e.target.value)}
                        className={`w-full px-3.5 py-2 rounded-xl text-[10px] font-medium outline-none border focus:ring-1.5 ${
                          isDark 
                            ? 'bg-[#25232A] border-[#36343B] text-[#E6E1E5] placeholder-[#938F99] focus:ring-[#D0BCFF]/30' 
                            : 'bg-white border-[#CAC4D0] text-slate-800 placeholder-slate-400 focus:ring-[#6750A4]/30'
                        }`}
                      />
                      {nameError && <p className="text-[8px] font-bold text-red-500 mt-1">{nameError}</p>}
                    </div>

                    {/* Category Selection */}
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-black uppercase tracking-wider text-[#49454F]">Business Category</label>
                      <div className="flex flex-wrap gap-1">
                        {CATEGORIES.map((cat) => (
                          <button
                            key={cat}
                            type="button"
                            onClick={() => setNewPlaceCategory(cat)}
                            className={`px-2.5 py-1 rounded-full text-[8px] font-bold border transition-all cursor-pointer ${
                              newPlaceCategory === cat
                                ? 'bg-[#6750A4] border-[#6750A4] text-white shadow-xs'
                                : isDark 
                                  ? 'bg-[#25232A] border-[#36343B] text-slate-300' 
                                  : 'bg-white border-[#CAC4D0] text-[#49454F] hover:bg-slate-50'
                            }`}
                          >
                            {cat}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Description Notes */}
                    <div className="space-y-1">
                      <label className="text-[9px] font-black uppercase tracking-wider text-[#49454F]">Description / Logistics Notes</label>
                      <textarea
                        rows={3}
                        placeholder="Add specific dock directions, key security codes, hours, lead times, or contact requirements..."
                        value={newPlaceNotes}
                        onChange={(e) => setNewPlaceNotes(e.target.value)}
                        className={`w-full px-3.5 py-2 rounded-xl text-[10px] font-medium outline-none border focus:ring-1.5 resize-none ${
                          isDark 
                            ? 'bg-[#25232A] border-[#36343B] text-[#E6E1E5] placeholder-[#938F99] focus:ring-[#D0BCFF]/30' 
                            : 'bg-white border-[#CAC4D0] text-slate-800 placeholder-slate-400 focus:ring-[#6750A4]/30'
                        }`}
                      />
                    </div>

                    {/* Color Priority Tag */}
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-black uppercase tracking-wider text-[#49454F]">Priority Label Tag</label>
                      <div className="grid grid-cols-4 gap-1.5 text-[8.5px] font-black uppercase tracking-wider text-center">
                        {[
                          { key: 'red', label: 'Urgent', color: '#EA4335' },
                          { key: 'green', label: 'Regular', color: '#34A853' },
                          { key: 'blue', label: 'VIP', color: '#4285F4' },
                          { key: 'yellow', label: 'Follow-up', color: '#FBBC05' }
                        ].map((item) => (
                          <button
                            key={item.key}
                            type="button"
                            onClick={() => setNewPlaceColorLabel(item.key as any)}
                            style={{ 
                              borderColor: newPlaceColorLabel === item.key ? item.color : '#E8E0EB',
                              backgroundColor: newPlaceColorLabel === item.key ? `${item.color}15` : 'transparent'
                            }}
                            className={`py-2 rounded-xl border-1.5 transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                              isDark ? 'text-slate-300' : 'text-slate-700'
                            }`}
                          >
                            <span style={{ backgroundColor: item.color }} className="w-2.5 h-2.5 rounded-full shadow-xs" />
                            <span>{item.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Is Favorite star toggle */}
                    <button
                      type="button"
                      onClick={() => setNewPlaceIsFavorite(prev => !prev)}
                      className={`w-full p-3 rounded-xl border flex items-center justify-between text-[9px] font-black uppercase tracking-wider cursor-pointer ${
                        newPlaceIsFavorite 
                          ? 'bg-amber-500/10 border-amber-500/35 text-amber-600' 
                          : isDark ? 'bg-[#25232A] border-[#36343B]' : 'bg-white border-[#CAC4D0] text-[#49454F]'
                      }`}
                    >
                      <span className="flex items-center gap-1.5">
                        <Star className={`w-4 h-4 ${newPlaceIsFavorite ? 'fill-amber-500 text-amber-500' : ''}`} />
                        <span>Add to Favorites List</span>
                      </span>
                      <span>{newPlaceIsFavorite ? 'Yes' : 'No'}</span>
                    </button>

                    {/* Advanced Fields: Contact info, reminders and checklists toggle */}
                    <div className="border-t border-[#E8E0EB] pt-3.5">
                      <button
                        type="button"
                        onClick={() => setIsAdvancedExpanded(!isAdvancedExpanded)}
                        className="w-full flex items-center justify-between text-[9px] font-black uppercase tracking-widest text-[#6750A4]"
                      >
                        <span>{isAdvancedExpanded ? 'Hide' : 'Show'} Rich Enterprise Fields</span>
                        <ChevronRight className={`w-4 h-4 transition-transform ${isAdvancedExpanded ? 'rotate-90' : ''}`} />
                      </button>

                      {isAdvancedExpanded && (
                        <div className="mt-3.5 space-y-4 pt-1">
                          
                          {/* Client Contact Info */}
                          <div className="space-y-2.5">
                            <span className="text-[8px] font-black uppercase tracking-wider text-slate-400 block border-b pb-1">Client Contact Info</span>
                            
                            <div className="space-y-2 text-[10px]">
                              <div>
                                <label className="text-[8px] font-black uppercase text-slate-500 block">Contact Person Name</label>
                                <input
                                  type="text"
                                  value={newPlaceOwnerName}
                                  onChange={(e) => setNewPlaceOwnerName(e.target.value)}
                                  placeholder="e.g. John Doe"
                                  className={`w-full px-3 py-1.5 rounded-lg border outline-none ${
                                    isDark ? 'bg-[#25232A] border-[#36343B]' : 'bg-white border-slate-300'
                                  }`}
                                />
                              </div>
                              <div className="grid grid-cols-2 gap-2">
                                <div>
                                  <label className="text-[8px] font-black uppercase text-slate-500 block">Phone</label>
                                  <input
                                    type="text"
                                    value={newPlacePhone}
                                    onChange={(e) => setNewPlacePhone(e.target.value)}
                                    placeholder="+1..."
                                    className={`w-full px-3 py-1.5 rounded-lg border outline-none ${
                                      isDark ? 'bg-[#25232A] border-[#36343B]' : 'bg-white border-slate-300'
                                    }`}
                                  />
                                </div>
                                <div>
                                  <label className="text-[8px] font-black uppercase text-slate-500 block">WhatsApp</label>
                                  <input
                                    type="text"
                                    value={newPlaceWhatsapp}
                                    onChange={(e) => setNewPlaceWhatsapp(e.target.value)}
                                    placeholder="+1..."
                                    className={`w-full px-3 py-1.5 rounded-lg border outline-none ${
                                      isDark ? 'bg-[#25232A] border-[#36343B]' : 'bg-white border-slate-300'
                                    }`}
                                  />
                                </div>
                              </div>
                              <div>
                                <label className="text-[8px] font-black uppercase text-slate-500 block">Email</label>
                                <input
                                  type="text"
                                  value={newPlaceEmail}
                                  onChange={(e) => setNewPlaceEmail(e.target.value)}
                                  placeholder="john@example.com"
                                  className={`w-full px-3 py-1.5 rounded-lg border outline-none ${
                                    isDark ? 'bg-[#25232A] border-[#36343B]' : 'bg-white border-slate-300'
                                  }`}
                                />
                              </div>
                            </div>
                          </div>

                          {/* Bullet Lists */}
                          <div className="space-y-2">
                            <span className="text-[8px] font-black uppercase tracking-wider text-slate-400 block border-b pb-1">Dispatch / Logistics Bullets</span>
                            <div className="flex gap-1">
                              <input
                                type="text"
                                value={bulletInput}
                                onChange={(e) => setBulletInput(e.target.value)}
                                placeholder="Add custom logistics detail..."
                                className={`flex-1 px-3 py-1.5 text-[9px] rounded-lg border outline-none ${
                                  isDark ? 'bg-[#25232A] border-[#36343B]' : 'bg-white border-slate-300'
                                }`}
                              />
                              <button
                                type="button"
                                onClick={addBulletPoint}
                                className="px-2.5 bg-[#6750A4] text-white rounded-lg text-xs font-bold"
                              >
                                +
                              </button>
                            </div>
                            {newPlaceBullets.length > 0 && (
                              <ul className="text-[9px] text-slate-500 list-disc pl-4 space-y-1">
                                {newPlaceBullets.map((b, i) => (
                                  <li key={i} className="flex items-center justify-between">
                                    <span className="truncate">{b}</span>
                                    <button
                                      type="button"
                                      onClick={() => setNewPlaceBullets(prev => prev.filter((_, idx) => idx !== i))}
                                      className="text-red-500 ml-1 hover:underline"
                                    >
                                      remove
                                    </button>
                                  </li>
                                ))}
                              </ul>
                            )}
                          </div>

                          {/* Task Checklists */}
                          <div className="space-y-2">
                            <span className="text-[8px] font-black uppercase tracking-wider text-slate-400 block border-b pb-1">Task Checklists</span>
                            <div className="flex gap-1">
                              <input
                                type="text"
                                value={checklistInput}
                                onChange={(e) => setChecklistInput(e.target.value)}
                                placeholder="Add task e.g. Audit diagnostics cabinet..."
                                className={`flex-1 px-3 py-1.5 text-[9px] rounded-lg border outline-none ${
                                  isDark ? 'bg-[#25232A] border-[#36343B]' : 'bg-white border-slate-300'
                                }`}
                              />
                              <button
                                type="button"
                                onClick={addChecklistItem}
                                className="px-2.5 bg-[#6750A4] text-white rounded-lg text-xs font-bold"
                              >
                                +
                              </button>
                            </div>
                            {newPlaceChecklist.length > 0 && (
                              <div className="space-y-1 text-[9px]">
                                {newPlaceChecklist.map((c, i) => (
                                  <div key={c.id} className="flex items-center justify-between p-1 rounded hover:bg-slate-50">
                                    <span className="truncate">{c.text}</span>
                                    <button
                                      type="button"
                                      onClick={() => setNewPlaceChecklist(prev => prev.filter(chk => chk.id !== c.id))}
                                      className="text-red-500 hover:underline"
                                    >
                                      remove
                                    </button>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>

                          {/* Reminder Interval */}
                          <div className="space-y-1.5">
                            <span className="text-[8px] font-black uppercase tracking-wider text-slate-400 block border-b pb-1">Routine Visit Interval Reminders</span>
                            <div className="grid grid-cols-4 gap-1">
                              {[
                                { val: null, label: 'None' },
                                { val: 7, label: '7 days' },
                                { val: 30, label: 'Monthly' },
                                { val: 90, label: 'Quarterly' }
                              ].map((rem) => (
                                <button
                                  key={rem.label}
                                  type="button"
                                  onClick={() => setNewPlaceReminderInterval(rem.val)}
                                  className={`py-1.5 rounded-lg border text-[8px] font-bold ${
                                    newPlaceReminderInterval === rem.val
                                      ? 'bg-[#E8DEF8] border-[#D0BCFF] text-[#1D192B]'
                                      : 'bg-[#FAF8FC] border-slate-300 text-[#49454F]'
                                  }`}
                                >
                                  {rem.label}
                                </button>
                              ))}
                            </div>
                          </div>

                        </div>
                      )}
                    </div>

                  </div>

                  {/* Form Submission CTA Buttons */}
                  <div className={`p-4.5 border-t flex items-center gap-3 shrink-0 ${
                    isDark ? 'bg-[#1D1B20] border-[#36343B]' : 'bg-[#FAF8FC] border-[#E8E0EB]'
                  }`}>
                    <button
                      onClick={() => setActiveScreen('home')}
                      className={`flex-1 py-3 text-[10px] font-black uppercase tracking-wider rounded-xl border text-center transition-all active:scale-98 cursor-pointer ${
                        isDark ? 'border-[#36343B] text-slate-300 hover:bg-white/5' : 'border-slate-300 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSaveLocation}
                      className="flex-1 py-3 bg-[#6750A4] text-white font-black text-[10px] uppercase tracking-wider rounded-xl transition-all active:scale-98 shadow-md flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{editingLocationId ? 'Save Changes' : 'Save Location'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* SCREEN 4: DETAILED LOCATION VIEW SCREEN */}
              {activeScreen === 'view_details' && selectedLocation && (
                <div className="flex-1 flex flex-col min-h-0 relative">
                  
                  {/* View Header */}
                  <div className={`px-4.5 py-3 border-b flex items-center justify-between shrink-0 z-10 relative ${
                    isDark ? 'bg-[#1D1B20] border-[#36343B]' : 'bg-white border-[#E8E0EB]'
                  }`}>
                    <button 
                      onClick={() => setActiveScreen('home')}
                      className={`p-1.5 rounded-lg border hover:bg-slate-50 flex items-center gap-1 cursor-pointer ${
                        isDark ? 'border-[#36343B] text-slate-200' : 'border-slate-200 text-slate-700'
                      }`}
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                    </button>
                    
                    <span className="text-[10px] font-black uppercase tracking-wider text-[#6750A4] truncate max-w-[140px]">
                      {selectedLocation.shopName}
                    </span>

                    <button
                      onClick={() => toggleFavorite(selectedLocation.id)}
                      className="p-1 text-amber-500 transition-all hover:scale-105 active:scale-95 cursor-pointer"
                    >
                      <Star className={`w-5 h-5 ${selectedLocation.isFavorite ? 'fill-amber-500 text-amber-500' : 'text-slate-400'}`} />
                    </button>
                  </div>

                  {/* View Scrollable Body */}
                  <div className={`flex-grow overflow-y-auto min-h-0 ${isDark ? 'bg-[#141218]' : 'bg-[#FAF8FC]'}`}>
                    
                    {/* Maps picker in read-only mode at top of details */}
                    <div className="h-44 border-b border-slate-200 bg-slate-100 relative shrink-0">
                      <MapPicker
                        selectedLat={selectedLocation.latitude}
                        setSelectedLat={() => {}}
                        selectedLng={selectedLocation.longitude}
                        setSelectedLng={() => {}}
                        selectedAddress={selectedLocation.address}
                        setSelectedAddress={() => {}}
                        appTheme={appTheme}
                        readOnly={true}
                      />
                    </div>

                    <div className="p-4.5 space-y-4.5">
                      
                      {/* Name, Category and priority badges */}
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className={`text-[8px] font-black uppercase px-2.5 py-1 rounded-full ${
                            isDark ? 'bg-[#D0BCFF]/10 text-[#D0BCFF]' : 'bg-[#E8DEF8] text-[#1D192B]'
                          }`}>
                            {selectedLocation.category}
                          </span>
                          
                          <span 
                            style={{
                              backgroundColor: 
                                selectedLocation.colorLabel === 'red' ? '#EA4335' : 
                                selectedLocation.colorLabel === 'green' ? '#34A853' : 
                                selectedLocation.colorLabel === 'blue' ? '#4285F4' : '#FBBC05'
                            }}
                            className="px-2.5 py-1 rounded-full text-[7.5px] font-black uppercase text-white shadow-xs"
                          >
                            {selectedLocation.colorLabel || 'regular'}
                          </span>
                        </div>
                        <h2 className={`text-base font-black tracking-tight ${isDark ? 'text-white' : 'text-[#1D1B20]'}`}>
                          {selectedLocation.shopName}
                        </h2>
                        <p className="text-[9px] text-[#49454F] font-semibold leading-relaxed">
                          {selectedLocation.address}
                        </p>
                      </div>

                      {/* Notes Box */}
                      <div className={`p-4 rounded-2xl border ${
                        isDark ? 'bg-[#1D1B20] border-[#36343B]' : 'bg-white border-[#E8E0EB]'
                      }`}>
                        <span className="text-[8px] font-black uppercase text-slate-400 tracking-wider">Logistics / Notes</span>
                        <p className="text-[9.5px] text-slate-600 leading-relaxed italic mt-1 font-medium">
                          "{selectedLocation.notes || 'No notes description cataloged yet.'}"
                        </p>
                      </div>

                      {/* Contact Action Cards */}
                      {selectedLocation.contactInfo && (selectedLocation.contactInfo.ownerName || selectedLocation.contactInfo.phone) && (
                        <div className={`p-4 rounded-2xl border space-y-2.5 ${
                          isDark ? 'bg-[#1D1B20] border-[#36343B]' : 'bg-white border-[#E8E0EB]'
                        }`}>
                          <span className="text-[8px] font-black uppercase text-slate-400 tracking-wider">Contact Card Details</span>
                          
                          <div className="text-[9.5px] font-semibold space-y-1.5">
                            {selectedLocation.contactInfo.ownerName && (
                              <p className="flex items-center gap-1.5">
                                <User className="w-3.5 h-3.5 text-[#6750A4]" />
                                <span>Owner: {selectedLocation.contactInfo.ownerName}</span>
                              </p>
                            )}
                            {selectedLocation.contactInfo.phone && (
                              <div className="flex items-center justify-between gap-1.5">
                                <p className="flex items-center gap-1.5 truncate">
                                  <Phone className="w-3.5 h-3.5 text-[#6750A4]" />
                                  <span>Phone: {selectedLocation.contactInfo.phone}</span>
                                </p>
                                <a 
                                  href={`tel:${selectedLocation.contactInfo.phone}`} 
                                  className="text-[8px] font-black text-[#6750A4] uppercase hover:underline"
                                >
                                  Call
                                </a>
                              </div>
                            )}
                            {selectedLocation.contactInfo.whatsapp && (
                              <div className="flex items-center justify-between gap-1.5">
                                <p className="flex items-center gap-1.5 truncate">
                                  <MessageSquare className="w-3.5 h-3.5 text-[#34A853]" />
                                  <span>WhatsApp: {selectedLocation.contactInfo.whatsapp}</span>
                                </p>
                                <a 
                                  href={`https://wa.me/${selectedLocation.contactInfo.whatsapp.replace(/\D/g,'')}`} 
                                  target="_blank" 
                                  rel="noopener noreferrer" 
                                  className="text-[8px] font-black text-[#34A853] uppercase hover:underline"
                                >
                                  Chat
                                </a>
                              </div>
                            )}
                            {selectedLocation.contactInfo.email && (
                              <p className="flex items-center gap-1.5 text-slate-500 truncate">
                                <Mail className="w-3.5 h-3.5 text-slate-400" />
                                <span className="truncate">Email: {selectedLocation.contactInfo.email}</span>
                              </p>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Interactive Checklists */}
                      {selectedLocation.richNotes?.checklists && selectedLocation.richNotes.checklists.length > 0 && (
                        <div className={`p-4 rounded-2xl border space-y-2.5 ${
                          isDark ? 'bg-[#1D1B20] border-[#36343B]' : 'bg-white border-[#E8E0EB]'
                        }`}>
                          <span className="text-[8px] font-black uppercase text-slate-400 tracking-wider">Assigned Checklist Tasks</span>
                          
                          <div className="space-y-1.5">
                            {selectedLocation.richNotes.checklists.map((chk, idx) => (
                              <div 
                                key={chk.id} 
                                onClick={() => toggleViewChecklistItem(idx)}
                                className="flex items-center gap-2 p-1.5 rounded hover:bg-slate-50 cursor-pointer"
                              >
                                <div className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${
                                  chk.done ? 'bg-green-500 border-green-500 text-white' : 'border-slate-400'
                                }`}>
                                  {chk.done && <Check className="w-3 h-3 text-white stroke-[3]" />}
                                </div>
                                <span className={`text-[10px] font-medium truncate ${chk.done ? 'line-through text-slate-400' : 'text-slate-700'}`}>
                                  {chk.text}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Logistics bullets */}
                      {selectedLocation.richNotes?.bullets && selectedLocation.richNotes.bullets.length > 0 && (
                        <div className={`p-4 rounded-2xl border space-y-2 ${
                          isDark ? 'bg-[#1D1B20] border-[#36343B]' : 'bg-white border-[#E8E0EB]'
                        }`}>
                          <span className="text-[8px] font-black uppercase text-slate-400 tracking-wider font-sans">Corporate Logistics details</span>
                          <ul className="text-[9.5px] text-slate-500 pl-4 space-y-1.5 list-disc leading-relaxed font-semibold">
                            {selectedLocation.richNotes.bullets.map((b, i) => (
                              <li key={i} className="text-slate-600">{b}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Reminders banner */}
                      {selectedLocation.reminderInterval && (
                        <div className="p-3.5 bg-amber-500/10 border border-amber-500/20 text-amber-600 rounded-2xl text-[9px] font-black uppercase tracking-wider flex items-center gap-2">
                          <Clock className="w-4 h-4 text-amber-500 shrink-0" />
                          <span>Interval Reminder Set: Every {selectedLocation.reminderInterval} Days</span>
                        </div>
                      )}

                      {/* Photos mockup placeholders */}
                      {selectedLocation.photos && Object.keys(selectedLocation.photos).length > 0 && (
                        <div className={`p-4 rounded-2xl border space-y-2.5 ${
                          isDark ? 'bg-[#1D1B20] border-[#36343B]' : 'bg-white border-[#E8E0EB]'
                        }`}>
                          <span className="text-[8px] font-black uppercase text-slate-400 tracking-wider">Attached Image Files</span>
                          <div className="grid grid-cols-4 gap-1.5">
                            {Object.entries(selectedLocation.photos).map(([key, imgVal]) => (
                              <div key={key} className="flex flex-col items-center">
                                <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center text-[#6750A4] border border-slate-200">
                                  <ImageIcon className="w-5 h-5 text-slate-400" />
                                </div>
                                <span className="text-[6px] font-bold text-slate-400 uppercase mt-1 truncate max-w-full">{key}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Visit history logs */}
                      <div className={`p-4 rounded-2xl border space-y-3.5 ${
                        isDark ? 'bg-[#1D1B20] border-[#36343B]' : 'bg-white border-[#E8E0EB]'
                      }`}>
                        <div className="flex items-center justify-between">
                          <span className="text-[8px] font-black uppercase text-slate-400 tracking-wider">Check-In Visit History ({selectedLocation.visitHistory?.length || 0})</span>
                          <button
                            onClick={() => setIsCheckInDialogOpen(true)}
                            className="px-2.5 py-1 bg-[#6750A4] text-white font-black text-[8px] uppercase tracking-wider rounded-lg transition-all active:scale-95 cursor-pointer"
                          >
                            + Check-in
                          </button>
                        </div>

                        {/* Record visit list */}
                        {(!selectedLocation.visitHistory || selectedLocation.visitHistory.length === 0) ? (
                          <p className="text-[9px] text-center text-slate-400 italic">No visit history logs recorded yet.</p>
                        ) : (
                          <div className="space-y-3 font-medium text-[9px] text-slate-600">
                            {selectedLocation.visitHistory.map((v) => (
                              <div key={v.id} className="border-l-2 border-[#6750A4] pl-2.5 space-y-0.5 relative">
                                <div className="flex items-center justify-between text-[7px] text-slate-400 font-bold uppercase leading-none mb-0.5">
                                  <span>{v.date} | {v.time}</span>
                                  {v.latitude && (
                                    <span className="font-mono">GPS OK</span>
                                  )}
                                </div>
                                <p className="leading-normal italic text-slate-700">"{v.notes}"</p>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                    </div>
                  </div>

                  {/* Actions CTA Bottom Bar */}
                  <div className={`p-4 border-t flex gap-2 shrink-0 ${
                    isDark ? 'bg-[#1D1B20] border-[#36343B]' : 'bg-[#FAF8FC] border-[#E8E0EB]'
                  }`}>
                    <button
                      onClick={(e) => startEditLocation(selectedLocation, e)}
                      className={`flex-1 py-3 text-[10px] font-black uppercase tracking-wider rounded-xl border text-center transition-all active:scale-98 cursor-pointer ${
                        isDark ? 'border-[#36343B] text-slate-300 hover:bg-white/5' : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      Edit Note
                    </button>
                    <a
                      href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(selectedLocation.address)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-grow py-3 bg-[#6750A4] text-white font-black text-[10px] uppercase tracking-wider rounded-xl transition-all active:scale-98 shadow-md flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Compass className="w-3.5 h-3.5" />
                      <span>Navigate Route</span>
                    </a>
                  </div>

                  {/* Modal Overlay: Check-In Visit Dialog */}
                  {isCheckInDialogOpen && (
                    <div className="absolute inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
                      <div className={`w-full max-w-xs p-4 rounded-3xl border shadow-xl space-y-3.5 ${
                        isDark ? 'bg-[#1D1B20] border-[#36343B]' : 'bg-white border-slate-200'
                      }`}>
                        <div className="text-center">
                          <MapPin className="w-7 h-7 text-[#6750A4] mx-auto mb-1 animate-pulse" />
                          <h4 className="text-[11px] font-black uppercase tracking-wider">Record Visit Check-In</h4>
                          <p className="text-[8px] text-[#49454F] leading-normal max-w-[90%] mx-auto font-medium mt-1">
                            Saving will automatically register GPS coordinates log and store visit history metadata.
                          </p>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[8px] font-black uppercase tracking-wider text-slate-400 block">Visit Notes</label>
                          <textarea
                            rows={3}
                            placeholder="Type client requests, supply delivery count, follow-ups..."
                            value={visitNoteText}
                            onChange={(e) => setVisitNoteText(e.target.value)}
                            className={`w-full p-2 text-[10px] rounded-xl outline-none border focus:ring-1.5 resize-none ${
                              isDark ? 'bg-[#25232A] border-[#36343B] focus:ring-[#D0BCFF]/20' : 'bg-[#FAF8FC] border-slate-300 focus:ring-[#6750A4]/20'
                            }`}
                          />
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setIsCheckInDialogOpen(false)}
                            className="flex-1 py-2 rounded-xl border text-[9px] font-black uppercase text-center text-slate-500 cursor-pointer hover:bg-slate-50"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={handleCheckInSubmit}
                            disabled={isGettingLocation}
                            className="flex-1 py-2 bg-[#6750A4] text-white font-black text-[9px] uppercase rounded-xl transition-all active:scale-95 flex items-center justify-center gap-1 cursor-pointer shadow"
                          >
                            <span>{isGettingLocation ? 'Tracking...' : 'Save Log'}</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                </div>
              )}

            </div>
          )}
        </AnimatePresence>
      </div>

      {/* Mock Hardware Android Nav Bar */}
      <div className={`h-12 flex items-center justify-around px-12 z-40 relative border-t select-none shrink-0 ${
        isDark ? 'bg-[#141218] border-[#36343B] text-slate-400' : 'bg-[#FAF8FC] border-[#E8E0EB] text-slate-600'
      }`}>
        <button onClick={() => setActiveScreen('home')} className="hover:text-[#6750A4] p-1.5 cursor-pointer">
          <svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24"><path d="M4 10v11h6v-6h4v6h6V10l-8-7z"/></svg>
        </button>
        <button onClick={() => { if (selectedLocation) setActiveScreen('view_details'); }} className="hover:text-[#6750A4] p-1.5 cursor-pointer">
          <svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>
        </button>
        <button onClick={handleAddNewLocationInit} className="hover:text-[#6750A4] p-1.5 cursor-pointer">
          <svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z"/></svg>
        </button>
      </div>
    </div>
  );
}

// Splash Screen Subcomponent
function SplashSimulatorScreen({ isDark }: { isDark: boolean; key?: string }) {
  return (
    <div className={`flex-grow flex flex-col items-center justify-center text-center relative ${
      isDark ? 'bg-[#141218]' : 'bg-[#FAF8FC]'
    }`}>
      {/* Central animated ring ripples */}
      <div className="absolute w-24 h-24 rounded-full border border-[#6750A4]/30 bg-[#6750A4]/3 animate-ping" />
      <div className="absolute w-16 h-16 rounded-full border border-[#6750A4]/15 bg-[#6750A4]/5 animate-pulse" />

      {/* Floating Center Map pin */}
      <motion.div
        initial={{ scale: 0.7, opacity: 0, y: 15 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{ duration: 0.8, type: "spring", bounce: 0.4 }}
        className="w-14 h-14 bg-[#6750A4] rounded-[24px] flex items-center justify-center shadow-lg border border-[#D0BCFF]/20 relative z-10"
      >
        <MapPin className="w-7 h-7 text-white" />
      </motion.div>

      {/* Title */}
      <h3 className={`text-base font-extrabold tracking-wider mt-3 font-sans relative z-10 ${isDark ? 'text-white' : 'text-[#1D1B20]'}`}>
        Route<span className="text-[#6750A4]">Book</span>
      </h3>
      <p className="text-[8px] text-slate-400 uppercase tracking-widest mt-0.5 relative z-10 font-bold">
        Offline-First Map Notebook
      </p>
    </div>
  );
}
