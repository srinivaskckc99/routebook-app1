# Security Specification for RouteBook

This document outlines the security architecture, invariants, and threat-vector test payloads designed to validate the robust access controls of the RouteBook Firestore database.

## 1. Data Invariants

1. **Identity Isolation**: A user's locations backup MUST only be accessible (read/write/delete) by the owner of the document, whose authenticated UID exactly matches the document ID.
2. **Path Hardening**: Document IDs (such as `{userId}`) must be valid strings adhering to alphanumeric formats, with length constraints to prevent resource poisoning.
3. **Strict Schema Completeness**: Every backup document must contain exactly the keys `locations` and `updatedAt`, with no unmapped/ghost fields.
4. **Type Integrity**: The `locations` property must be a list (array) and `updatedAt` must be an integer (timestamp).
5. **Verified Authenticity**: All write operations must be executed by authenticated users whose email addresses have been verified.

---

## 2. The "Dirty Dozen" Threat Payloads

These payloads represent malicious or malformed requests intended to bypass security logic. They must all be strictly rejected by the rules with `PERMISSION_DENIED`.

### 1. Identity Spoofing (Write to another user's space)
- **Document Path**: `/users/victim_user_id`
- **Caller UID**: `attacker_user_id`
- **Payload**:
  ```json
  {
    "locations": [],
    "updatedAt": 1719662100000
  }
  ```

### 2. Unauthorized Read (Accessing victim's data)
- **Document Path**: `/users/victim_user_id`
- **Caller UID**: `attacker_user_id`
- **Operation**: `get`

### 3. Missing Required Fields (Missing locations)
- **Document Path**: `/users/my_user_id`
- **Caller UID**: `my_user_id`
- **Payload**:
  ```json
  {
    "updatedAt": 1719662100000
  }
  ```

### 4. Missing Required Fields (Missing updatedAt)
- **Document Path**: `/users/my_user_id`
- **Caller UID**: `my_user_id`
- **Payload**:
  ```json
  {
    "locations": []
  }
  ```

### 5. Ghost Field Injection (Shadow update)
- **Document Path**: `/users/my_user_id`
- **Caller UID**: `my_user_id`
- **Payload**:
  ```json
  {
    "locations": [],
    "updatedAt": 1719662100000,
    "isAdmin": true
  }
  ```

### 6. ID Poisoning (Malformed document ID string)
- **Document Path**: `/users/user_id_with_special_characters_$%^&*()`
- **Caller UID**: `user_id_with_special_characters_$%^&*()`
- **Payload**:
  ```json
  {
    "locations": [],
    "updatedAt": 1719662100000
  }
  ```

### 7. Type Mismatch (updatedAt as string)
- **Document Path**: `/users/my_user_id`
- **Caller UID**: `my_user_id`
- **Payload**:
  ```json
  {
    "locations": [],
    "updatedAt": "2026-06-30"
  }
  ```

### 8. Type Mismatch (locations as object)
- **Document Path**: `/users/my_user_id`
- **Caller UID**: `my_user_id`
- **Payload**:
  ```json
  {
    "locations": {},
    "updatedAt": 1719662100000
  }
  ```

### 9. Unauthenticated Write (No Auth token)
- **Document Path**: `/users/any_user_id`
- **Caller UID**: `null` (Anonymous/Unauthenticated)
- **Payload**:
  ```json
  {
    "locations": [],
    "updatedAt": 1719662100000
  }
  ```

### 10. Unverified Email Access
- **Document Path**: `/users/my_user_id`
- **Caller UID**: `my_user_id` (Auth token has `email_verified: false`)
- **Payload**:
  ```json
  {
    "locations": [],
    "updatedAt": 1719662100000
  }
  ```

### 11. Resource Poisoning (Oversized ID)
- **Document Path**: `/users/very_long_id_greater_than_128_characters_repeating_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
- **Caller UID**: `very_long_id_greater_than_128_characters_repeating_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
- **Payload**:
  ```json
  {
    "locations": [],
    "updatedAt": 1719662100000
  }
  ```

### 12. Write Overdue / Future Timestamp
- **Document Path**: `/users/my_user_id`
- **Caller UID**: `my_user_id`
- **Payload**:
  ```json
  {
    "locations": [],
    "updatedAt": 9999999999999
  }
  ```

---

## 3. Test Assertions Suite

```typescript
// firestore.rules.test.ts placeholder logic representation
describe("Firestore Security Rules", () => {
  it("should block unauthenticated read/writes", () => {
    // Assert: anonymous.get('/users/user_1') -> PERMISSION_DENIED
    // Assert: anonymous.set('/users/user_1', payload) -> PERMISSION_DENIED
  });

  it("should block mismatched user IDs", () => {
    // Assert: user_1.get('/users/user_2') -> PERMISSION_DENIED
    // Assert: user_1.set('/users/user_2', payload) -> PERMISSION_DENIED
  });

  it("should block unverified email writes", () => {
    // Assert: user_1_unverified.set('/users/user_1', payload) -> PERMISSION_DENIED
  });

  it("should allow valid backups", () => {
    // Assert: user_1.set('/users/user_1', validPayload) -> ALLOWED
    // Assert: user_1.get('/users/user_1') -> ALLOWED
  });

  it("should block invalid schemas (ghost fields, bad types)", () => {
    // Assert: user_1.set('/users/user_1', invalidPayloadWithGhostField) -> PERMISSION_DENIED
    // Assert: user_1.set('/users/user_1', invalidPayloadBadType) -> PERMISSION_DENIED
  });
});
```
